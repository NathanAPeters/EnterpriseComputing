<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/connection.php';
include_once '../students/student.php';
$student = new student();


//$student->deleteById(59);
//$student->updateById(21);


//$student->getAll();

//$uid = $_GET['userId'];
//$student->getById($uid);

$student->setValues("6","jimbo", "30200", "46");
$student->insert();

/*
//in postman
{
    id:10,
    name:john,
    num:12345,
    age:19,
}

//some post method to convert to this result
s=
{
    id:10,
    name:john,
    num:12345,
    age:19,
}

$Student->setValues(s->id,s->name,s->num,s->age);
*/
?>