<!-- 

$sql = "INSERT INTO `student` (`id`, `student_name`, `student_number`, `student_age`) VALUES (\'21\', \'Mark\', \'23422\', \'30\');";

Create a 'students' MySQL database with a student table that has the following columns:
`id` primary key
`student_name` the name of the student
`student_number`
`student_age` the age of the student


create connection.php file and add MySQL 
connection string to connect MySQL with 
php using mysqli_connect() method

create students.php file and add MySQL 
connection file to access database 
table data.

Connect to the database
use $_SERVER method to access action information

Write the following functions
update_student($id)  
delete_student() 






//INSERT INTO `student` (`id`, `student_name`, `student_number`, `student_age`) VALUES ('21', 'Mark', '23422', '30');
//INSERT INTO `student` (`id`, `student_name`, `student_number`, `student_age`) VALUES ('59', 'Jack Human', '98772', '20');





-->